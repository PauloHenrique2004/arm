<?php

namespace Symfony\Component\Config\Tests\Fixtures;

class BadParent extends MissingParent
{
}
