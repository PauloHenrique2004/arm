<?php

namespace Josegonzalez\Upload\Validation;

use Josegonzalez\Upload\Validation\Traits\ImageValidationTrait;

class ImageValidation
{
    use ImageValidationTrait;
}
