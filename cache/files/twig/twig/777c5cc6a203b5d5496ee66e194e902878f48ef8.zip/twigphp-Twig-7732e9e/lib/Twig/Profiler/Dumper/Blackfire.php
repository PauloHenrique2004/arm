<?php

use Twig\Profiler\Dumper\BlackfireDumper;

class_exists('Twig\Profiler\Dumper\BlackfireDumper');

if (\false) {
    class Twig_Profiler_Dumper_Blackfire extends BlackfireDumper
    {
    }
}
