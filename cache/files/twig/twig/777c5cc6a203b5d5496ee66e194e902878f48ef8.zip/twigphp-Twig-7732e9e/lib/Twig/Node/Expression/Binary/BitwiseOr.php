<?php

use Twig\Node\Expression\Binary\BitwiseOrBinary;

class_exists('Twig\Node\Expression\Binary\BitwiseOrBinary');

if (\false) {
    class Twig_Node_Expression_Binary_BitwiseOr extends BitwiseOrBinary
    {
    }
}
