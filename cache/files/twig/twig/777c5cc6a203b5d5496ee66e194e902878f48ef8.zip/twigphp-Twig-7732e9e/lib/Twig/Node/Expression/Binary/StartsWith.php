<?php

use Twig\Node\Expression\Binary\StartsWithBinary;

class_exists('Twig\Node\Expression\Binary\StartsWithBinary');

if (\false) {
    class Twig_Node_Expression_Binary_StartsWith extends StartsWithBinary
    {
    }
}
