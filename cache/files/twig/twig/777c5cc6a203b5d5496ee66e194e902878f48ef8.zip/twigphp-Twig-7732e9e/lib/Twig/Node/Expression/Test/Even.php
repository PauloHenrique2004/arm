<?php

use Twig\Node\Expression\Test\EvenTest;

class_exists('Twig\Node\Expression\Test\EvenTest');

if (\false) {
    class Twig_Node_Expression_Test_Even extends EvenTest
    {
    }
}
