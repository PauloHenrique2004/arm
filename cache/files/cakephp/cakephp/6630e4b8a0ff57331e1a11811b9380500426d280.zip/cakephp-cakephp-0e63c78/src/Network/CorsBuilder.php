<?php
// @deprecated 3.6.0 Backwards compatibility alias
class_alias('Cake\Http\CorsBuilder', 'Cake\Network\CorsBuilder');
deprecationWarning('Use Cake\Http\CorsBuilder instead of Cake\Network\CorsBuilder.');
