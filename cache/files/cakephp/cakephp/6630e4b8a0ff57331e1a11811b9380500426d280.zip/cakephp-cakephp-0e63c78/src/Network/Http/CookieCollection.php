<?php
// @deprecated 3.4.0 Load new class and alias.
class_exists('Cake\Http\Client\CookieCollection');
deprecationWarning('Use Cake\Http\Client\CookieCollection instead of Cake\Network\Http\CookieCollection.');
