<?php
// @deprecated 3.6.0 Backward compatibility alias
class_alias('Cake\Http\Exception\ConflictException', 'Cake\Network\Exception\ConflictException');
deprecationWarning('Use Cake\Http\Exception\ConflictException instead of Cake\Network\Exception\ConflictException.');
