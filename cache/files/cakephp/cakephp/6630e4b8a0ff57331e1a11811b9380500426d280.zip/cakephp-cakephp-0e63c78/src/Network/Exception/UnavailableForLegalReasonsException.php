<?php
// @deprecated 3.6.0 Backward compatibility alias
class_alias('Cake\Http\Exception\UnavailableForLegalReasonsException', 'Cake\Network\Exception\UnavailableForLegalReasonsException');
deprecationWarning('Use Cake\Http\Exception\UnavailableForLegalReasonsException instead of Cake\Network\Exception\UnavailableForLegalReasonsException.');
