<?php
// @deprecated 3.5.0 Backward compatibility with 2.x, 3.0.x
class_alias('Cake\Mailer\Transport\DebugTransport', 'Cake\Network\Email\DebugTransport');
deprecationWarning('Use Cake\Mailer\Transport\DebugTransport instead of Cake\Network\Email\DebugTransport.');
